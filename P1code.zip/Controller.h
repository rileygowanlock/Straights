#ifndef STRAIGHTS_CONTROLLER_H
#define STRAIGHTS_CONTROLLER_H
#include "Model.h"
#include "Command.h"

class Controller {
private:
    Model* model_; //model instance
public:
    Controller(Model* model);
    void invitePlayers(char playerType, int playerNum);
    bool gamePlay (Command &command, Player* player);
    int newGame();
};

#endif //STRAIGHTS_CONTROLLER_H
